package com.androidsrc.client;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import android.os.AsyncTask;
import android.widget.TextView;

import android.os.AsyncTask;

import java.io.*;
import java.net.Socket;

public class Client extends AsyncTask<String, Void, Void>
{
	private Exception exception;
//	String dstAddress;
//	int dstPort;
////	String response = "";
////	TextView textResponse;
////
//	Client(String addr, int port)
//	{
//		dstAddress = addr;
//		dstPort = port;
//	}
//	Client()
//	{
//
//	}
	@Override

	protected Void doInBackground(String... params)
	{
		try
		{
			try
			{
				Socket socket=new Socket("192.168.43.21", 12345);
				PrintWriter outToServer=new PrintWriter(
						new OutputStreamWriter(
								socket.getOutputStream()));
				outToServer.print(params[0]);
				outToServer.flush();

			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		catch(Exception e)
		{
			this.exception=e;
			return null;
		}
		return null;
	}
}